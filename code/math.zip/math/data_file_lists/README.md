# Mathematica File Lists

This folder contains lists of files in the Mathematica section of AMPS.
The files are separated out into training files with steps and those without steps. The dataloaders in `math/modeling` rely on these files to load data.


